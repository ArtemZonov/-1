package com.company;

import java.util.ArrayList;

public class Main {

     static String s;

    public static void main(String[] args) {

        correctLogin();
        pasword();
        correctEmail();
        correctAge();
        correctAdress();
        
    }
    static void correctLogin(){
        String login = "luda1990";

        ArrayList<String> logins = new ArrayList<>();
        logins.add("luda1994");
        logins.add("luda1995");
        logins.add("lyda1992");
        logins.add("lida1989");
        logins.add("lyuda1991");

        for(String s : logins) {
        }
        Main.s = s;
        if(s == login){
            System.out.println("Такой логин уже есть!");
        } else {
            System.out.println("Ваш логин принят!");
        }

    }
    static void pasword(){

        String password = "12345abc";
        String confirmPasword = "12345abc";

        if(confirmPasword == password){
            System.out.println("Ваш пароль принят!");
        } else{
            System.out.println("Неверный пароль! Подтвердите еще раз!");
        }

    }

    static void correctEmail(){
        String email = "luda@mail.com";

        if(email.contains("@")){
            if(email.contains(".")){
                System.out.println("Введенный email адрес корректен!");
            }
        } else{
            System.out.println("Email адрес должен содержать амперсанд (@) и точку!");
        }

    }

    static void correctAge(){
        int age = 12;

        if(age <= 18){
            System.out.println("Ваш возраст должен быть не менее 18 лет!");
        } else{
            System.out.println("Ваш возраст соответствует требованиям!");
        }
    }

    static void correctAdress(){
        String adress = "Japan, Tokyo, Lano st., 12, 44883";

        if(adress.contains("Ukraine")){
            System.out.println("Адрес принят!");
        } else{
            System.out.println("Страна должна быть -- Украина!");
        }
    }


    }



